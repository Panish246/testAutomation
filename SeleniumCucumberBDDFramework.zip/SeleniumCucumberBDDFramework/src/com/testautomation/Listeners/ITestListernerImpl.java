package com.testautomation.Listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;



public class ITestListernerImpl extends ExtentReportListerner  implements ITestListener  {

	private static ExtentReports extent;
	
	public void onTestStart(ITestResult result) {  //excutes before the test script excuetes
		// TODO Auto-generated method stub
		
		
	}


	public void onTestSuccess(ITestResult result) {//after the test script  excuetes
		System.out.println("..........PASS.......");
		
	}


	public void onTestFailure(ITestResult result) {//after the test script  excuetes
		System.out.println("......FAIL.......");
		
	}

	
	public void onTestSkipped(ITestResult result) {//After the test script excuetes(if test script skipped)
		System.out.println("........SKIPPED........");
		
	}


	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {//after test script excuetes 70%->Pass less then fail
		// TODO Auto-generated method stub
		
	}


	public void onStart(ITestContext context) {//this will start before all the test cases starts
		System.out.println("Excuetion started on UAT Env...........");
		extent=setUp();
		
	}

	
	public void onFinish(ITestContext context) {//this will after before all the test cases starts
		System.out.println("Excuetion completed on UAT Env...........");
		extent.flush();
		System.out.println("Generated Report........");
		
	}

}
