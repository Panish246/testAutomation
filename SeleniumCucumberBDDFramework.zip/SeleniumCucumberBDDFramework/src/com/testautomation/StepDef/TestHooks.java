package com.testautomation.StepDef;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class TestHooks {
	
	@Before//Before the scenario
	public void beforeScenario(Scenario scenario )
	{
		
		System.out.println("Started Excuetion for the Scenario "+scenario.getName());
	}
	
	@Before("@TestCase2")//Before the scenario
	public void beforeScenarioTestCase2(Scenario scenario )
	{
		System.out.println("...........................");
		System.out.println(" Excueting  for the Scenario "+scenario.getName());
		System.out.println("...........................");
	}
	
	@After//after the scenario
	public void afterScenario(Scenario scenario)
	
	{
		System.out.println("Completed Excuetion for the Scenario "+scenario.getName());
	}

}
