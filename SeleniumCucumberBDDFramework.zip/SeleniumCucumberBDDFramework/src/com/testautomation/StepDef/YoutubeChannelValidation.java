package com.testautomation.StepDef;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.gherkin.model.Scenario;
import com.testautomation.Listeners.ExtentReportListerner;
import com.testautomation.PageObjects.YouTubeChannelPage;
import com.testautomation.PageObjects.YoutubeResultsPage;
import com.testautomation.PageObjects.YoutubeSearchPage;
import com.testautomation.Utility.BrowserUtility;
import com.testautomation.Utility.PropertiesFileReader;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class YoutubeChannelValidation extends ExtentReportListerner {

	public static WebDriver driver;
	PropertiesFileReader obj = new PropertiesFileReader();

	@Given("^Open Chrome browser with URL$")
	public void open_Chrome_browser_with_URL() throws Throwable {

		ExtentTest logInfo = null;
		try {

			test = extent.createTest(Feature.class, "Youtube channel name validation");
			test = test.createNode(Scenario.class, "Youtube channel name validations");
			logInfo = test.createNode(new GherkinKeyword("Given"), "open_Chrome_browser_with_URL");
			Properties properties = obj.getProperty();
			driver = BrowserUtility.OpenBrowser(driver, properties.getProperty("browser.name"),
					properties.getProperty("browser.baseurl"));
			logInfo.pass("Open Chrome Browser and Entered URL");
			//logInfo.addScreenCaptureFromPath(captureScreenShot(driver));

		} catch (AssertionError | Exception e) {
			testStepHandle("FAIL", driver, logInfo, e);
		}

	}

	@When("^Search selenium tutorial$")
	public void search_selenium_tutorial() throws Throwable {

		ExtentTest logInfo = null;
		try {
			logInfo = test.createNode(new GherkinKeyword("When"), "search_selenium_tutorial");
			new YoutubeSearchPage(driver).NavigateToResultPage();
			logInfo.pass("Search selenium Tutorial");
			//logInfo.addScreenCaptureFromPath(captureScreenShot(driver));

		} catch (AssertionError | Exception e) {
			testStepHandle("FAIL", driver, logInfo, e);
		}

	}

	@When("^Search selenium tutorial \"(.*)\"$")
	public void search_selenium_tutorial(String searchString) throws Throwable {

		ExtentTest logInfo = null;
		try {
			logInfo = test.createNode(new GherkinKeyword("When"), "search_selenium_tutorial(String searchString)");
			new YoutubeSearchPage(driver).NavigateToResultPage(searchString);
			logInfo.pass("Search selenium Tutorial");
			//logInfo.addScreenCaptureFromPath(captureScreenShot(driver));

		} catch (AssertionError | Exception e) {
			testStepHandle("FAIL", driver, logInfo, e);
		}

	}

	@When("^Click on channel name$")
	public void click_on_channel_name() throws Throwable {

		ExtentTest logInfo = null;
		try {
			logInfo = test.createNode(new GherkinKeyword("When"), "search_selenium_tutorial()");
			new YoutubeResultsPage(driver).NavigateToChannelName();
			logInfo.pass("Clicked Channel Name");
			//logInfo.addScreenCaptureFromPath(captureScreenShot(driver));

		} catch (AssertionError | Exception e) {
			testStepHandle("FAIL", driver, logInfo, e);
		}

	}

	@Then("^Validate channel name$")
	public void validate_channel_name() throws Throwable {

		ExtentTest logInfo = null;
		try {
			logInfo = test.createNode(new GherkinKeyword("Then"), "validate_channel_name");
			String expectedChannelName = "Cucumber(BDD) Selenium Framework Full Course 2 by Bakkappa N - YouTube";
			//String expectedChannelName = "Full Course 2 by Bakkappa N - YouTube";
			String actualChannelName = new YouTubeChannelPage(driver).getTitle();
			Assert.assertEquals(actualChannelName, expectedChannelName, "Channel names are not matching");		
			logInfo.pass("Validated Channel title");
			//logInfo.addScreenCaptureFromPath(captureScreenShot(driver));
			driver.quit();

		} catch (AssertionError | Exception e) {
			testStepHandle("FAIL", driver, logInfo, e);
		}

	}

}
